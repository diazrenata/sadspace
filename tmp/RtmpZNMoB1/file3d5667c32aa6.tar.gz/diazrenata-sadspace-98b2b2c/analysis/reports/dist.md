SAD space report
================

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

    ## Warning in summary.lm(fs_lm): essentially perfect fit: summary may be unreliable

![](dist_files/figure-markdown_github/plots-1.png)![](dist_files/figure-markdown_github/plots-2.png)![](dist_files/figure-markdown_github/plots-3.png)![](dist_files/figure-markdown_github/plots-4.png)![](dist_files/figure-markdown_github/plots-5.png)
